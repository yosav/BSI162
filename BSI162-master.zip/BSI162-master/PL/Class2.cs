﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedClasses;
using PL;
using BL;

namespace PL
{
    class Class2 : PL
    {
        public status login()
        {
            Console.WriteLine("Please enter your username");
            string tempUsername = Console.ReadLine();
            Console.WriteLine("Please enter your password");
            string tempPassword = Console.ReadLine();
            User user = new User(tempUsername, tempPassword);

            return Login(user);
        }

        public void Init()
        {
            Console.WriteLine("Wellcome to BSI162!");
            Run();
        }

        public void Run()
        {
            status tempStatus = login();
            int numOfAttemptsLeft = 5;
            while (tempStatus==status.incorrect)
            {
                numOfAttemptsLeft--;
                login();
                Console.WriteLine("You have " + numOfAttemptsLeft + "attempts left");
            }
            if(tempStatus==status.locked)
            {
                Console.WriteLine("Sorry! The application will shut down now");
            }
            if (tempStatus == status.correct)
            {
                Console.WriteLine("Wellcome");
            }
        }

        public bool changePassword(User user)
        {
            throw new NotImplementedException();
/*          Console.WriteLine("Please enter your new password");
            String suggestedPassword = Console.ReadLine();
            return  changePassword(user, suggestedPassword);
 */     }
    }
}
