﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using SharedClasses;

namespace BL
{
    class Class2 : BL
    {
        private int numOfAttempts = 0;
        private readonly int MAXATTEMPTS = 5;

        public bool changePassword(User user, string suggestedPassword)
        {
            throw new NotImplementedException();
        }

        public status Login(User user)
        {
            numOfAttempts++;
            bool found =  searchUser(user);
            if (found == false)
            {
                if (numOfAttempts < MAXATTEMPTS)
                    return status.correct;
                else
                    return status.locked;
            }
            else
                return status.correct;
        }

        public bool resetPassword(User user)
        {
            throw new NotImplementedException();
        }
    }
}
