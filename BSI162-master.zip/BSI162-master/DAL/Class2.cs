﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedClasses;
using System.IO;

namespace DAL
{
    class Class2 : DAL
    {
        System.IO.StreamReader sr = new StreamReader("");

        public bool changePassword(User user)
        {
            throw new NotImplementedException();
        }

        public bool searchUser(User user)
        {
            String currLine;
            while((currLine = sr.ReadLine())!=null)
            {
                if (currLine.Equals(user.getUserName()))
                {
                    if ((currLine = sr.ReadLine()).Equals(user.getPassword()))
                        return true;
                }
            }
            return false;
        }
    }
}
